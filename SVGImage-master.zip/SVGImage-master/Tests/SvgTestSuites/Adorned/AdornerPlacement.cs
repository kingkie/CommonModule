﻿// Copyright c Bloomberg LP 2010"

using System;

namespace SvgTestSuites
{
    /// <summary>
    /// Specifies the placement of the adorner in related to the adorned control.
    /// </summary>
    public enum AdornerPlacement
    {
        Inside,
        Outside
    }
}
