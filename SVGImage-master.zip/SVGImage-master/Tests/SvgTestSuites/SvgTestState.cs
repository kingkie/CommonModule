﻿using System;

namespace SvgTestSuites
{
    public enum SvgTestState
    {
        Unknown = 0,
        Failure = 1,
        Success = 2,
        Partial = 3
    }
}
