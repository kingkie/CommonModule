using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SVGImage.Design
{
    using System.Windows;
    public partial class EditorResources : ResourceDictionary
    {
        public EditorResources()
            : base()
        {
            InitializeComponent();
        }
    }
}
