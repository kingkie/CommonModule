﻿namespace SVGImage.SVG
{
    public enum Visibility
    {
        Visible,
        Hidden
    }
}
