﻿namespace DotNetProjects.SVGImage.SVG.Animation
{
    public enum AnimateTransformType
    {
        Translate,
        Scale,
        Rotate,
        SkewX,
        SkewY
    }
}
