﻿using System.Xml;
using SVGImage.SVG.Shapes;

namespace DotNetProjects.SVGImage.SVG.Animation
{
    public class AnimateColor : AnimationBase
    {
        public AnimateColor(global::SVGImage.SVG.SVG svg, XmlNode node, Shape parent)
            : base(svg, node, parent)
        {
        }
    }
}
