﻿using System.Windows.Controls;

namespace XamlEditor.Views
{
    /// <summary>
    /// Interaction logic for EditorControl.xaml
    /// </summary>
    public partial class EditorControl : UserControl
    {
        public EditorControl()
        {
            InitializeComponent();
        } 
    }
}
