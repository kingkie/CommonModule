﻿using System.Windows.Controls;

namespace XamlDesigner.Views
{
    /// <summary>
    /// Interaction logic for DesignerControl.xaml
    /// </summary>
    public partial class DesignerControl : UserControl
    {
        public DesignerControl()
        {
            InitializeComponent();
        } 
    }
}
