﻿
namespace XamlTheme.Datas
{
    public enum TextCase
    {
        Normal,
        Upper,
        Lower
    }
}
