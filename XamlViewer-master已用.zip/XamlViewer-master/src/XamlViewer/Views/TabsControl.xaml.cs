﻿using System.Windows.Controls;

namespace XamlViewer.Views
{
    /// <summary>
    /// Interaction logic for DocumentControl.xaml
    /// </summary>
    public partial class TabsControl : UserControl
    { 
        public TabsControl()
        {
            InitializeComponent();
        }
    }
}
