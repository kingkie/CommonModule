﻿using XamlTheme.Controls;

namespace XamlViewer.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : UserWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
