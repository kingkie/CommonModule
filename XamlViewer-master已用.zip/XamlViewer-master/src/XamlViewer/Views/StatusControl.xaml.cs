﻿using System.Windows.Controls;

namespace XamlViewer.Views
{
    /// <summary>
    /// StatusControl.xaml 的交互逻辑
    /// </summary>
    public partial class StatusControl : UserControl
    {
        public StatusControl()
        {
            InitializeComponent();
        }
    }
}
