﻿
namespace XamlService.Payloads
{
    public class CaretPosition
    {
        public int Line { get; set; }
        public int Column { get; set; }
    }
}
