﻿
namespace XamlService
{
    public static class RegionNames
    {
        public const string DesignerName = "XamlDesignerRegion";
        public const string EditorName = "XamlEditorRegion";
        public const string WorkName = "WorkRegion";
    }
}
