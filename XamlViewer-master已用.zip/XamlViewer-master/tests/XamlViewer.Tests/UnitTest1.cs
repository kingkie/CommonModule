using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace XamlViewer.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
