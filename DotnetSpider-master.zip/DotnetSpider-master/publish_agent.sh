sh build_agent.sh
docker push dotnetspider/agent:latest