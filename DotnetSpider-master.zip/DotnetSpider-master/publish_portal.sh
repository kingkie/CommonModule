sh build_portal.sh
docker push dotnetspider/portal:latest