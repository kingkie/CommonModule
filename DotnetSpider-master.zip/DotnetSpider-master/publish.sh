sh publish_agent.sh
sh publish_portal.sh
sh publish_spiders.sh