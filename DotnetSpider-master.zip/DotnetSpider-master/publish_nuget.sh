#!/usr/bin/env bash
export NUGET_SERVER=https://api.nuget.org/v3/index.json
sh publish_package.sh