namespace DotnetSpider.Selector
{
    public enum SelectableType
    {
        Text,
        Html,
        Json
    }
}