// namespace DotnetSpider.Downloader
// {
// 	public interface IProxyDownloader
// 	{
// 	}
// }
