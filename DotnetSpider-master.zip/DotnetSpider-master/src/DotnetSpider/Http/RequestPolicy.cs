namespace DotnetSpider.Http
{
    public enum RequestPolicy
    {
        /// <summary>
        /// 随机
        /// </summary>
        Random,
		
        /// <summary>
        /// 链式
        /// </summary>
        Chained
    }
}