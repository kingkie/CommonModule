namespace DotnetSpider.Infrastructure
{
    public enum MySqlFileType
    {
        /// <summary>
        /// LOAD
        /// </summary>
        LoadFile,

        /// <summary>
        /// INSERT SQL语句
        /// </summary>
        InsertSql
    }
}