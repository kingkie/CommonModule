using System;

namespace DotnetSpider.Portal.Common
{
	public static class ServiceProvider
	{
		public static IServiceProvider Instance;
	}
}