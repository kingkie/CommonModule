namespace DotnetSpider.Tests
{
    public abstract class TestBase
    {
    }
}
