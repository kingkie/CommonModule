namespace DotnetSpider.MySql.Scheduler
{
	public class MySqlSchedulerOptions
	{
		public string ConnectionString { get; set; }
	}
}
