docker-compose  -f agent.yml down
docker-compose  -f agent.yml up -d
