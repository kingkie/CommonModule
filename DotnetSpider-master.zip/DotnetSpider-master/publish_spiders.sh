sh build_spiders.sh
docker push dotnetspider/spiders:latest